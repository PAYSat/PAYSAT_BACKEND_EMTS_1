import { db } from '../config/firebase.js';
import { COL } from '../utils/paysat_crypto_collections.js';
import { v4 as uuidv4 } from 'uuid';

function now() { return new Date(); }

export async function getOrCreateWalletTx(tx, uid, asset) {
  const assetU = String(asset).toUpperCase();

  // ✅ RUTA CORRECTA: PaySat_Crypto_Wallets/{uid}/assets/{ASSET}
  const ref = db
    .collection(COL.CRYPTO_WALLETS) // = PaySat_Crypto_Wallets
    .doc(uid)
    .collection('assets')
    .doc(assetU);

  const snap = await tx.get(ref);

  if (!snap.exists) {
    const data = {
      uid,
      asset: assetU,
      available: 0,
      escrow: 0,
      total: 0,
      createdAt: now(),
      updatedAt: now(),
    };
    tx.set(ref, data);
    return { ref, data };
  }

  return { ref, data: snap.data() };
}

// --- lo demás igual ---
export function assertAmount(amount) {
  const n = Number(amount);
  if (!Number.isFinite(n) || n <= 0) throw new Error('amount inválido');
  return Math.round(n * 100) / 100;
}

export function to2(n) {
  return Math.round(Number(n) * 100) / 100;
}

export async function ledgerWriteTx(tx, entry) {
  const id = entry.id || uuidv4();
  const ref = db.collection(COL.LEDGER).doc(id);
  tx.set(ref, {
    id,
    ...entry,
    createdAt: entry.createdAt || now(),
  });
  return id;
}

// import { db } from '../config/firebase.js';
// import { COL, walletDocId } from '../utils/paysat_crypto_collections.js';
// import { v4 as uuidv4 } from 'uuid';

// function now() { return new Date(); }

// export async function getOrCreateWalletTx(tx, uid, asset) {
//   const assetU = String(asset).toUpperCase();
//   const ref = db.collection(COL.WALLETS).doc(walletDocId(uid, assetU));
//   const snap = await tx.get(ref);

//   if (!snap.exists) {
//     const data = {
//       uid,
//       asset: assetU,
//       available: 0,
//       escrow: 0,
//       createdAt: now(),
//       updatedAt: now(),
//     };
//     tx.set(ref, data);
//     return { ref, data };
//   }

//   return { ref, data: snap.data() };
// }

// export function assertAmount(amount) {
//   const n = Number(amount);
//   if (!Number.isFinite(n) || n <= 0) throw new Error('amount inválido');
//   return Math.round(n * 100) / 100;
// }

// export function to2(n) {
//   return Math.round(Number(n) * 100) / 100;
// }

// export async function ledgerWriteTx(tx, entry) {
//   const id = entry.id || uuidv4();
//   const ref = db.collection(COL.LEDGER).doc(id);
//   tx.set(ref, {
//     id,
//     ...entry,
//     createdAt: entry.createdAt || now(),
//   });
//   return id;
// }
